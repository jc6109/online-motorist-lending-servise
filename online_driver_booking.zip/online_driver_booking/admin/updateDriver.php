<?php 
ob_start();
?>
<html>
<head>

<meta charset="UTF-8">
	<meta http-equiv="X-UA-compatible" content = "IE-edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel ="stylesheet" type ="text/css" href="css/bootstrap.min.css">
        <script src="jquery/jquery-3.3.1.min.js"></script>
        <script type = text/javascript src="js/bootstrap.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
  

</head>
<body>
<?php include "nav1.php"; 
include "dbconfigure.php";
$id = $_GET['id'];

?>
<div>




<div class = container style = "margin-top : 100px">
<h2 class = text-center>Edit Driver Profile</h2>
<?php 
$query = "select * from driver_register where reg_id='$id'";
$rs = my_select($query);
echo "<div class='table-responsive'>";
echo "<table class='table table-hover table-borderless'>";
while($column=mysql_fetch_array($rs))
{
echo '<form method = post>';
echo "<tr><th>RegistrationNo.</th> <td><input type = text name = 'reg_id' value = $column[0]></td></tr>";
echo "<tr><th>DriverName</th> <td><input type = text name = 'name' value = $column[1]></td></tr>";
echo "<tr><th>Age</th> <td><input type = text name = 'age' value = $column[2]></td></tr>";
echo "<tr><th>Address</th> <td><input type = text name = 'address' value = $column[3]></td></tr>";
echo "<tr><th>Mobile</th> <td><input type = text name = 'mobile' value = $column[4]></td></tr>";
echo "<tr><th>Email</th> <td><input type = text name = 'email' value = $column[5]></td></tr>";
echo "<tr><th>Licence</th> <td><input type = text name = 'licence' value = $column[7]></td></tr>";
echo "<tr><th>Charge</th> <td><input type = text name = 'charge' value = $column[8]></td></tr>";

echo "<tr><th>Country</th> <td><input type = text name = 'country' value = $column[9]></td></tr>";
echo "<tr><th>State</th> <td><input type = text name = 'state' value = $column[10]></td></tr>";
echo "<tr><th>City</th> <td><input type = text name = 'city' value = $column[11]></td></tr>";
echo "<tr><th>Description</th> <td><input type = text name = 'discription' value = $column[13]></td></tr>";
}
echo "</table>";
echo '<input type = submit value = "Submit" class="btn btn-primary" name="edit"></form>';
?>

</div>
<?php  //include "bottom.php"; ?>
<?php
if(isset($_POST['edit']))
{
$reg_id = $_POST['reg_id'];
$name = $_POST['name'];
$age = $_POST['age'];
$address = $_POST['address'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];

$licence = $_POST['licence'];
$charge = $_POST['charge'];
$country = $_POST['country'];
$state = $_POST['state'];
$city = $_POST['city'];
$discription = $_POST['discription'];

$query = "update driver_register set name='$name',age='$age',address='$address',mobile='$mobile',email='$email',lisence='$licence',charge='$charge',country='$country',state='$state',city='$city',discription='$discription' where reg_id='$reg_id'";
my_iud($query);
header("Location:viewdriver.php");
}
?>


</body>
</html>