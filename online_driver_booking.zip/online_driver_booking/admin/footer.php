<footer class="site-footer">
      <div class="container">
        

        <div class="row">
          
              

          
          
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <h2 style = "font-weight : bold">
          
            Copyright &copy; <script>document.write(new Date().getFullYear());</script> All Rights Reserved 
           
            </h2>
			<h4 style = "font-weight : bold ; color : blue" >
          
            Designed And Developed By <span style = "color : red">Pankaj Panjwani</span>
           
            </h2>
          </div>
          
        </div>
      </div>
    </footer>