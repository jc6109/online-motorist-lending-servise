<div class="nav-menu">
        <div class="bg transition">
            <div class="container-fluid fixed">
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="index.php" style="text-shadow: 2px 2px 4px #000000;color : #A20002"><b>Book Your Driver</b></a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="icon-menu"></span>
              </button>
                            <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                   <li class="nav-item active">
                                        <a class="nav-link" href="index.php" style = "color : red"><b>Home</b></a>
                                    </li>
                                    
                                    <li class="nav-item active">
                                        <a class="nav-link" href="adddriver1.php" style = "color : red"><b>ADD Driver</b></a>
                                    </li>
                                    
                                    <li class="nav-item active">
                                        <a class="nav-link" href="viewdriver.php" style = "color : red"><b>View Driver</b></a>
                                    </li>
                                    <li class="nav-item active">
                                        <a class="nav-link" href="signout.php" style = "color : red"><b>Logout</b></a>
                                    </li>
                                      </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>