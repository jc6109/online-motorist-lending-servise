


<?php 
ob_start();
?>
<html>
<head>
<meta charset="UTF-8">
	<meta http-equiv="X-UA-compatible" content = "IE-edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel ="stylesheet" type ="text/css" href="css/bootstrap.min.css">
        <script src="jquery/jquery-3.3.1.min.js"></script>
        <script type = text/javascript src="js/bootstrap.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>

</head>
<body>
<?php include "nav1.php";?>
<div>
<?php
/*
on authentic page, only valid users of website can visit
strangers(anonymous) are not allowed
*/
@session_start();
include_once "dbconfigure.php";
$msg="";
if(verifyuser())
{

	$un=fetchusername();
	$status = "logout";
$msg='Welcome $un , <br /><a href="index.php?a='.$status.'">Signout</a>';
/*echo '<td><a href="familyViewAdmin2.php?id='.$column['clientid'].'&gname='.$column['groupname'].'">*/
	
}
else
{
header("Location:loginerror.php");
}
?>



<div class="container">
  <h2 class=text-center style = "font-family : 'Monotype Corsiva' ; font-weight : bold ; color : #E6120E">Add Driver</h2>
<form method="post" enctype = "multipart/form-data">


<div class="form-group col-xs-8">
<label ><b>Driver Name</b></label>
<input type="text" name="name" id="name" class="form-control" >



<label><b>Age</b></label>
<input type="text" name = "age" id = "age" class="form-control">

<label><b>Address</b></label>
<input type="text" name = "address" id = "address" class="form-control">


<label><b>Mobile</b></label>
<input type="text" name = "mobile" id = "mobile" class="form-control">


<label><b>Email ID</b></label>
<input type="text" name="email" id="email" class="form-control" >

<label><b>Password</b></label>
<input type="text" name="password" id="password" class="form-control" >

<label><b>Licence</b></label>
<input type="text" name="lisence" id="lisence" class="form-control" >

<label><b>Charge</b></label>
<input type="text" name="charge" id="charge" class="form-control" >

<label><b>Country</b></label>
<input type="text" name="country" id="country" class="form-control" >

<label><b>State</b></label>
<input type="text" name="state" id="state" class="form-control" >

<label><b>City</b></label>
<input type="text" name="city" id="city" class="form-control" >

<label><b>Image</b></label>
<input type="text" name="image" id="image" class="form-control" >

<label><b>Description</b></label>
<input type="text" name="discription" id="discription" class="form-control" >




<br>
<input type="submit" class="btn btn-primary" name="save"  style = "width : 200px" value="Save"/>

</div>
</form>
</div>

<?php

//include "dbconfigure.php" ;
if(isset($_POST["save"]))
{

$name=$_POST['name'];
$age=$_POST['age'];
$address=$_POST['address'];
$mobile=$_POST['mobile'];

$email=$_POST['email'];
$password=$_POST['password'];
$lisence=$_POST['lisence'];
$charge=$_POST['charge'];

$country=$_POST['country'];
$state=$_POST['state'];
$city=$_POST['city'];

move_uploaded_file($_FILES['image']['tmp_name'],"uploadimage/".$_FILES['image']['name']);
			$image = "uploadimage/".$_FILES['image']['name'];

$discription=$_POST['discription'];






$query="insert into product(name,image,category,price,description) values('$name','$image','$category','$price','$description')";
$n = my_iud($query);
echo "<script>alert('SuccessFully saved')</script>";

}

?>
<?php  //include "bottom.php"; ?>





</body>
</html>