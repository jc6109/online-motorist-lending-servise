<?php
//fetch.php
if(isset($_POST["action"]))
{
 $connect = mysql_connect("localhost", "root", "");
 mysql_select_db("testing",$connect)
 $output = '';
 if($_POST["action"] == "country")
 {
  $query = "SELECT state FROM country_state_city WHERE country = '".$_POST["query"]."' GROUP BY state";
  $result = mysql_query($query,$connect);
  $output .= '<option value="">Select State</option>';
  while($row = mysql_fetch_array($result))
  {
   $output .= '<option value="'.$row["state"].'">'.$row["state"].'</option>';
  }
 }
 if($_POST["action"] == "state")
 {
  $query = "SELECT city FROM country_state_city WHERE state = '".$_POST["query"]."'";
  $result = mysql_query($query,$connect);
  $output .= '<option value="">Select City</option>';
  while($row = mysql_fetch_array($result))
  {
   $output .= '<option value="'.$row["city"].'">'.$row["city"].'</option>';
  }
 }
 echo $output;
}
?>
