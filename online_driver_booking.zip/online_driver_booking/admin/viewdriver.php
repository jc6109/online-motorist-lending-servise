<?php 
ob_start();
?>
<html>
<head>
<meta charset="UTF-8">
	<meta http-equiv="X-UA-compatible" content = "IE-edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel ="stylesheet" type ="text/css" href="css/bootstrap.min.css">
        <script src="jquery/jquery-3.3.1.min.js"></script>
        <script type = text/javascript src="js/bootstrap.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>

 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>

  <script type="text/javascript">
  $(document).ready(function () {
$('#myTable123').DataTable();
$('.dataTables_length').addClass('bs-select');
});

  </script>
  <link rel = stylesheet href=https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css>
</head>
<body>
<?php include "nav1.php";?>
<div>
<?php
/*
on authentic page, only valid users of website can visit
strangers(anonymous) are not allowed
*/
@session_start();
include_once "dbconfigure.php";
$msg="";
if(verifyuser())
{

	$un=fetchusername();
	$status = "logout";
$msg='Welcome $un , <br /><a href="index.php?a='.$status.'">Signout</a>';
/*echo '<td><a href="familyViewAdmin2.php?id='.$column['clientid'].'&gname='.$column['groupname'].'">*/
	
}
else
{
header("Location:loginerror.php");
}
?>



<div>


				<div class="container">
				    <div class=row>
				        <div class="col-sm-12">
  <h2 class = text-center style = "font-family : 'Monotype Corsiva' ; font-weight : bold ; color : #E6120E">View Drivers</h2>



</div>
    
</div>
</div>
<?php
//include "dbconfigure.php" ;


$query = "select * from driver_register";
$rs = my_select($query);

echo "<div class = container>";
 
echo "<div class = row>";
echo "<div class = col-sm-12>";
echo "<div class='table-responsive'>";
echo "<table class='table table-hover table-sm' style = 'overflow: scroll' id=myTable123>";
echo "<thead style = 'background-color : green ; color : white' >";
echo "<tr>";
echo "<th>DriverName</th>";
echo "<th>Age</th>";
echo "<th>Address</th>";
echo "<th>Mobile</th>";
echo "<th>Email</th>";
echo "<th>Licence</th>";
echo "<th>Charge</th>";
echo "<th>Country</th>";
echo "<th>State</th>";
echo "<th>City</th>";
echo "<th>Image</th>";
echo "<th>Description</th>";
echo "<th>Delete</th>";
echo "<th>Edit</th>";
echo "</tr>";
echo "</thead>";

echo '<tbody id="myTable">';
while($column=mysql_fetch_array($rs))
{
echo "<tr class='table-warning'>";
echo "<td>$column[1]</td>";
echo "<td>$column[2]</td>";
echo "<td>$column[3]</td>";
echo "<td>$column[4]</td>";
echo "<td>$column[5]</td>";
echo "<td>$column[7]</td>";
echo "<td>$column[8]</td>";
echo "<td>$column[9]</td>";
echo "<td>$column[10]</td>";
echo "<td>$column[11]</td>";
$image = $column['image'];
$imgpath = "/online_driver_booking/images/".$image;               														echo "<td><img src=$imgpath width='100'></td>";echo "<td>$column[13]</td>";			
echo '<td><a class="btn btn-danger" href="deleteDriver.php?id='.$column['reg_id'].'">Delete
													</a></td>';
																								
echo '<td><a class="btn btn-primary" href="updateDriver.php?id='.$column['reg_id'].'">Edit
													</a></td>';
																			
echo "</tr>";

}
echo "</tbody>";
echo "</table>";
echo "</div>";
echo "</div>";
echo "</div>";
echo "</div>";






?>



<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>



</div>
<!--<?php  //include "bottom.php "?>-->


</body>
</html>