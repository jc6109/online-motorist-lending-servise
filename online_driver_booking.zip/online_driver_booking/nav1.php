<div class="nav-menu">
        <div class="bg transition">
            <div class="container-fluid fixed">
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="index.php" style="text-shadow: 2px 2px 4px #000000;">Book Your Driver</a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="icon-menu"></span>
              </button>
                            <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                   <li class="nav-item active">
                                        <a class="nav-link" href="mybooking.php">Home</a>
                                    </li>
                                    
                                    <li class="nav-item active">
                                        <a class="nav-link" href="editprofiledriver.php">Edit Profile</a>
                                    </li>
                                    
                                    
                                    <li class="nav-item">
                                        <a class="nav-link" href="book_ride.php">Logout</a>
                                    </li>
                                      </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>