-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2019 at 11:07 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.1.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testing`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--
create database testing;
use testing;

use testing;
CREATE TABLE IF NOT EXISTS `admin` (
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');



CREATE TABLE `booking` (
  `b_id` int(3) NOT NULL,
  `city` varchar(40) NOT NULL,
  `date` varchar(30) NOT NULL,
  `duration` int(3) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mobile` varchar(32) NOT NULL,
  `email` varchar(30) NOT NULL,
  `vehical` varchar(30) NOT NULL,
  `driverid` int(3) NOT NULL,
  `status` varchar(34) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`b_id`, `city`, `date`, `duration`, `name`, `mobile`, `email`, `vehical`, `driverid`, `status`) VALUES
(1, 'Ottawa', '2019-01-31', 3, 'anshu', '7745990607', 'anshu@gmail.com', 'LMV', 6, '2'),
(2, 'Ottawa', '2019-01-31', 3, 'anshu', '9752376639', 'samir@gmail.com', 'LMV', 1, '2');

-- --------------------------------------------------------

--
-- Table structure for table `country_state_city`
--

CREATE TABLE `country_state_city` (
  `id` int(11) NOT NULL,
  `country` varchar(250) NOT NULL,
  `state` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country_state_city`
--

INSERT INTO `country_state_city` (`id`, `country`, `state`, `city`) VALUES
(1, 'USA', 'New York', 'New York city'),
(2, 'USA', 'New York', 'Buffalo'),
(3, 'USA', 'New York', 'Albany'),
(4, 'USA', 'Alabama', 'Birmingham'),
(5, 'USA', 'Alabama', 'Montgomery'),
(6, 'USA', 'Alabama', 'Huntsville'),
(7, 'USA', 'California', 'Los Angeles'),
(8, 'USA', 'California', 'San Francisco'),
(9, 'USA', 'California', 'San Diego'),
(10, 'Canada', 'Ontario', 'Toronto'),
(11, 'Canada', 'Ontario', 'Ottawa'),
(12, 'Canada', 'British Columbia', 'Vancouver'),
(13, 'Canada', 'British Columbia', 'Victoria'),
(14, 'Australia', 'New South Wales', 'Sydney'),
(15, 'Australia', 'New South Wales', 'Newcastle'),
(16, 'Australia', 'Queensland', 'City of Brisbane'),
(17, 'Australia', 'Queensland', 'Gold Coast\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `driver_register`
--

CREATE TABLE `driver_register` (
  `reg_id` int(4) NOT NULL,
  `name` varchar(30) NOT NULL,
  `age` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `lisence` varchar(10) NOT NULL,
  `charge` varchar(40) NOT NULL,
  `country` varchar(32) NOT NULL,
  `state` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `image` varchar(60) NOT NULL,
  `discription` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driver_register`
--

INSERT INTO `driver_register` (`reg_id`, `name`, `age`, `address`, `mobile`, `email`, `password`, `lisence`, `charge`, `country`, `state`, `city`, `image`, `discription`) VALUES
(1, 'anshu parihar', '20', 'h.no.-20indrapuri ', '7412589632', 'anshu@gmail.com', '111111', 'LMV', '300', 'Canada', 'Ontario', 'Ottawa', 'criminalcasevittoriocapecchi.png', '\r\n   UYISE UIOUOIGY '),
(2, 'navin thakur', '36', 'bheela nager', '7896541258', 'navin@gmail.com ', '111111', 'LMV', '900', 'Australia', 'New South Wales', 'Sydney', 'man_PNG6533.png', 'alkjflajo ruotip opriopyt   '),
(3, 'vishal', '25', 'neelbad ', '7412589636', 'vishal@gmail.com', '111111', 'HMV', '300', 'Australia', 'Queensland', 'Gold Coast\r\n', 'adult-beach-beard-736716.jpg', 'fu8rtuo pyopw u quyrut bvjs\r\n   '),
(4, 'nitin', '20', 'ashoka garden', '7896541236', 'nitin@gmail.com', '111111', 'LMV', '600', 'Australia', 'New South Wales', 'Sydney', 'fp1-mobile-4.jpg', 'Discription...\r\n   '),
(5, 'neeraj', '35', 'fjiuruito', '7896541236', 'neeraj@gmail.com', '111111', 'LMV', '600', 'Australia', 'New South Wales', 'Sydney', 'DWIGHT-POLER-Bain-webpic.jpg', 'Discription...\r\n   '),
(6, 'raju', '36', 'eriutuio', '7896541236', 'raju@gmail.com', '111111', 'LMV', '300', 'Canada', 'Ontario', 'Ottawa', 'adult-beach-beard-736716.jpg', 'Discription...\r\n   '),
(7, 'vipin ', 'jain', 'raj nager', '8745896589', 'vipin@gmail.com', '111111', 'HMV', '600', 'Australia', 'Queensland', 'Gold Coast\r\n', 'fp1-mobile-4.jpg', 'Discription...\r\n   ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `country_state_city`
--
ALTER TABLE `country_state_city`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `driver_register`
--
ALTER TABLE `driver_register`
  ADD PRIMARY KEY (`reg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `b_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `country_state_city`
--
ALTER TABLE `country_state_city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `driver_register`
--
ALTER TABLE `driver_register`
  MODIFY `reg_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
